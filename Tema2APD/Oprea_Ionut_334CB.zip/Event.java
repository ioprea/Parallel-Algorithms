//Oprea Ionut 334CB

public class Event {
	//numarul N si tipul evenimentului generat
	int number;
	String type; 
				
	public Event(int number,String type){
		this.number = number;
		this.type = type;
	}
		
}
